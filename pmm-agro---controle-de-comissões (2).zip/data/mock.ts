import { Cliente, Pedido, Nota, Pagamento, Comissao, StatusCliente, FormaPagamento, ResponsavelPagamento, User, UserRole } from '../types.ts';

// Helper to generate UUIDs
const uuid = () => crypto.randomUUID();

export const USERS: User[] = [
  { id: uuid(), name: 'João (Proprietário)', role: UserRole.Proprietario },
  { id: uuid(), name: 'Ana (Financeiro)', role: UserRole.Financeiro },
  { id: uuid(), name: 'Carlos (Contador)', role: UserRole.Visualizador },
];

export const CLIENTES: Cliente[] = [
  {
    id: 'c1',
    nome: 'Fazenda Agro Sol',
    razao_social: 'Agro Sol Ltda',
    cnpj: '11.111.111/0001-11',
    cidade_uf: 'Campo Grande, MS',
    telefone: '(67) 99999-1111',
    segmento: 'Agronegócio',
    status: StatusCliente.Ativo,
    comissao_padrao: 0.03,
    created_at: new Date('2023-01-15'),
    updated_at: new Date('2023-01-15'),
  },
  {
    id: 'c2',
    nome: 'Sementes Brasil',
    razao_social: 'Sementes do Brasil S/A',
    cnpj: '22.222.222/0001-22',
    cidade_uf: 'Rondonópolis, MT',
    telefone: '(66) 99999-2222',
    segmento: 'Agronegócio',
    status: StatusCliente.Ativo,
    comissao_padrao: 0.035,
    created_at: new Date('2023-02-20'),
    updated_at: new Date('2023-02-20'),
  },
  {
    id: 'c3',
    nome: 'Terra Forte Insumos',
    razao_social: 'Terra Forte Comércio',
    cnpj: '33.333.333/0001-33',
    cidade_uf: 'Dourados, MS',
    telefone: '(67) 99999-3333',
    segmento: 'Agronegócio',
    status: StatusCliente.Inativo,
    comissao_padrao: 0.03,
    created_at: new Date('2023-03-10'),
    updated_at: new Date('2023-03-10'),
  },
];

export const PEDIDOS: Pedido[] = [
  {
    id: 'p1',
    numero: 'PED-2024-001',
    cliente_id: 'c1',
    data_pedido: new Date('2024-05-01'),
    tons: 100,
    preco_ton: 550,
    prazo_dias: 30,
    created_at: new Date('2024-05-01'),
    updated_at: new Date('2024-05-01'),
  },
  {
    id: 'p2',
    numero: 'PED-2024-002',
    cliente_id: 'c2',
    data_pedido: new Date('2024-05-10'),
    tons: 250,
    preco_ton: 600,
    prazo_dias: 45,
    created_at: new Date('2024-05-10'),
    updated_at: new Date('2024-05-10'),
  },
  {
    id: 'p3',
    numero: 'PED-2024-003',
    cliente_id: 'c1',
    data_pedido: new Date('2024-06-05'),
    tons: 50,
    preco_ton: 560,
    prazo_dias: 20,
    created_at: new Date('2024-06-05'),
    updated_at: new Date('2024-06-05'),
  },
  {
    id: 'p4',
    numero: 'PED-2024-004',
    cliente_id: 'c3',
    data_pedido: new Date('2024-06-15'),
    tons: 300,
    preco_ton: 590,
    prazo_dias: 60,
    created_at: new Date('2024-06-15'),
    updated_at: new Date('2024-06-15'),
  },
];

export const NOTAS: Nota[] = [
  // Pedido 1
  {
    id: 'n1',
    numero: 'NFE-0001',
    pedido_id: 'p1',
    data_emissao: new Date('2024-05-02'),
    tons: 50,
    valor_nota: 27500,
    created_at: new Date('2024-05-02'),
    updated_at: new Date('2024-05-02'),
  },
  {
    id: 'n2',
    numero: 'NFE-0002',
    pedido_id: 'p1',
    data_emissao: new Date('2024-05-05'),
    tons: 50,
    valor_nota: 27500,
    created_at: new Date('2024-05-05'),
    updated_at: new Date('2024-05-05'),
  },
  // Pedido 2
  {
    id: 'n3',
    numero: 'NFE-0003',
    pedido_id: 'p2',
    data_emissao: new Date('2024-05-11'),
    tons: 100,
    valor_nota: 60000,
    created_at: new Date('2024-05-11'),
    updated_at: new Date('2024-05-11'),
  },
  {
    id: 'n4',
    numero: 'NFE-0004',
    pedido_id: 'p2',
    data_emissao: new Date('2024-05-15'),
    tons: 150,
    valor_nota: 90000,
    created_at: new Date('2024-05-15'),
    updated_at: new Date('2024-05-15'),
  },
  // Pedido 3
  {
    id: 'n5',
    numero: 'NFE-0005',
    pedido_id: 'p3',
    data_emissao: new Date('2024-06-06'),
    tons: 50,
    valor_nota: 28000,
    created_at: new Date('2024-06-06'),
    updated_at: new Date('2024-06-06'),
  },
  // Pedido 4
  {
    id: 'n6',
    numero: 'NFE-0006',
    pedido_id: 'p4',
    data_emissao: new Date('2024-06-16'),
    tons: 150,
    valor_nota: 88500,
    created_at: new Date('2024-06-16'),
    updated_at: new Date('2024-06-16'),
  },
  {
    id: 'n7',
    numero: 'NFE-0007',
    pedido_id: 'p4',
    data_emissao: new Date('2024-06-20'),
    tons: 150,
    valor_nota: 88500,
    created_at: new Date('2024-06-20'),
    updated_at: new Date('2024-06-20'),
  },
];

export const PAGAMENTOS: Pagamento[] = [
  // Pagamento total para NFE-0001
  {
    id: 'pg1',
    nota_id: 'n1',
    data_pagamento: new Date('2024-06-01'),
    valor_pago: 27500,
    forma_pagamento: FormaPagamento.PIX,
    vencimento_original: new Date('2024-05-31'),
    created_at: new Date('2024-06-01'),
    updated_at: new Date('2024-06-01'),
  },
  // Pagamento parcial para NFE-0003
  {
    id: 'pg2',
    nota_id: 'n3',
    data_pagamento: new Date('2024-06-20'),
    valor_pago: 30000,
    forma_pagamento: FormaPagamento.Boleto,
    vencimento_original: new Date('2024-06-25'),
    created_at: new Date('2024-06-20'),
    updated_at: new Date('2024-06-20'),
  },
  // Pagamento atrasado para NFE-0005
  {
    id: 'pg3',
    nota_id: 'n5',
    data_pagamento: new Date('2024-07-05'),
    valor_pago: 28000,
    forma_pagamento: FormaPagamento.TED,
    vencimento_original: new Date('2024-06-25'),
    created_at: new Date('2024-07-05'),
    updated_at: new Date('2024-07-05'),
  },
  // Outro pagamento parcial para NFE-0003
  {
    id: 'pg4',
    nota_id: 'n3',
    data_pagamento: new Date('2024-07-10'),
    valor_pago: 30000,
    forma_pagamento: FormaPagamento.Boleto,
    vencimento_original: new Date('2024-06-25'),
    created_at: new Date('2024-07-10'),
    updated_at: new Date('2024-07-10'),
  },
];

// Comissões são geradas a partir de pagamentos
export const COMISSOES: Comissao[] = [
  // Comissão para NFE-0001 (totalmente paga)
  {
    id: 'co1',
    nota_id: 'n1',
    cliente_id: 'c1',
    percentual: 0.03,
    valor_base: 27500, // valor do pagamento pg1
    valor_comissao: 27500 * 0.03,
    valor_pago: 0,
    responsavel_pagamento: ResponsavelPagamento.Propria,
    created_at: new Date('2024-06-01'),
    updated_at: new Date('2024-06-01'),
  },
  // Comissão para NFE-0003 (baseada nos pagamentos pg2 e pg4)
  {
    id: 'co2',
    nota_id: 'n3',
    cliente_id: 'c2',
    percentual: 0.035,
    valor_base: 60000, // 30000 + 30000
    valor_comissao: 60000 * 0.035,
    valor_pago: 1000, // pagamento parcial da comissão
    responsavel_pagamento: ResponsavelPagamento.Propria,
    created_at: new Date('2024-06-20'),
    updated_at: new Date('2024-07-10'),
  },
  // Comissão para NFE-0005 (paga)
  {
    id: 'co3',
    nota_id: 'n5',
    cliente_id: 'c1',
    percentual: 0.03,
    valor_base: 28000,
    valor_comissao: 28000 * 0.03,
    valor_pago: 28000 * 0.03, // comissão totalmente paga
    responsavel_pagamento: ResponsavelPagamento.Terceiro,
    created_at: new Date('2024-07-05'),
    updated_at: new Date('2024-07-05'),
  },
];