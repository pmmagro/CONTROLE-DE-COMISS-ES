import React, { useEffect, useState } from 'react';
import { Cliente, Pedido } from '../types.ts';
import { apiService } from '../services/apiService.ts';
import { formatCurrency } from '../utils/helpers.ts';
import Card from '../components/ui/Card.tsx';

const Clientes: React.FC = () => {
    const [clientes, setClientes] = useState<Cliente[]>([]);
    const [pedidos, setPedidos] = useState<Pedido[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            const [cls, pds] = await Promise.all([
                apiService.getClientes(),
                apiService.getPedidos(),
            ]);
            setClientes(cls);
            setPedidos(pds);
            setLoading(false);
        };
        fetchData();
    }, []);

    const getTotalVendido = (clienteId: string) => {
        return pedidos
            .filter(p => p.cliente_id === clienteId)
            .reduce((sum, p) => sum + (p.tons * p.preco_ton), 0);
    };

    if (loading) {
        return <div>Carregando clientes...</div>;
    }

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-800">Clientes</h1>
            <Card>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cidade/UF</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Comissão</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Total Vendido</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {clientes.map((cliente) => (
                                <tr key={cliente.id} className="hover:bg-gray-50">
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <div className="text-sm font-medium text-gray-900">{cliente.nome}</div>
                                        <div className="text-sm text-gray-500">{cliente.cnpj}</div>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{cliente.cidade_uf}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                            cliente.status === 'Ativo' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                        }`}>
                                            {cliente.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{(cliente.comissao_padrao * 100).toFixed(2)}%</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-800">{formatCurrency(getTotalVendido(cliente.id))}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default Clientes;