import React from 'react';
import Card from '../components/ui/Card.tsx';
import { Download } from 'lucide-react';

const Relatorios: React.FC = () => {
    
    // Dummy handler for button clicks
    const handleDownload = (reportName: string) => {
        alert(`Gerando relatório: ${reportName}`);
        // In a real app, this would trigger a CSV/PDF generation.
    };

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-800">Relatórios</h1>
            
            <Card>
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Exportar Dados</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <button onClick={() => handleDownload('Comissões Recebidas vs Pendentes')} className="flex items-center justify-center p-4 bg-agro-green text-white rounded-lg hover:bg-agro-green/90 transition-colors">
                        <Download className="mr-2" />
                        Comissões (Recebidas vs Pendentes)
                    </button>
                    <button onClick={() => handleDownload('Notas em Aberto/Parcial')} className="flex items-center justify-center p-4 bg-agro-green text-white rounded-lg hover:bg-agro-green/90 transition-colors">
                        <Download className="mr-2" />
                        Notas em Aberto/Parcial
                    </button>
                    <button onClick={() => handleDownload('Extrato por Cliente')} className="flex items-center justify-center p-4 bg-agro-green text-white rounded-lg hover:bg-agro-green/90 transition-colors">
                        <Download className="mr-2" />
                        Extrato por Cliente
                    </button>
                </div>
            </Card>

            <Card>
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Relatório de Cobrança (PDF)</h2>
                 <p className="text-gray-600 mb-4">
                    Gere um PDF com as notas em aberto ou parciais, agrupadas por cliente, para facilitar o processo de cobrança.
                </p>
                <button onClick={() => handleDownload('Relatório de Cobrança em PDF')} className="flex items-center justify-center p-4 bg-agro-gold text-agro-green font-bold rounded-lg hover:opacity-90 transition-opacity">
                    <Download className="mr-2" />
                    Gerar PDF de Cobrança
                </button>
            </Card>
        </div>
    );
};

export default Relatorios;