import React, { useEffect, useState } from 'react';
import { Cliente, Pedido, Nota, Pagamento, Comissao } from '../types.ts';
import { apiService } from '../services/apiService.ts';
import { formatCurrency, getValorPagoPorNota } from '../utils/helpers.ts';
import KpiCard from '../components/ui/KpiCard.tsx';
import Card from '../components/ui/Card.tsx';
import { getTotalPedido } from '../utils/helpers.ts';
import { DollarSign, AlertTriangle, FileCheck2, BarChart2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';


const Dashboard: React.FC = () => {
    const [clientes, setClientes] = useState<Cliente[]>([]);
    const [pedidos, setPedidos] = useState<Pedido[]>([]);
    const [notas, setNotas] = useState<Nota[]>([]);
    const [pagamentos, setPagamentos] = useState<Pagamento[]>([]);
    const [comissoes, setComissoes] = useState<Comissao[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            const [cls, pds, nts, pgs, cms] = await Promise.all([
                apiService.getClientes(),
                apiService.getPedidos(),
                apiService.getNotas(),
                apiService.getPagamentos(),
                apiService.getComissoes()
            ]);
            setClientes(cls);
            setPedidos(pds);
            setNotas(nts);
            setPagamentos(pgs);
            setComissoes(cms);
            setLoading(false);
        };
        fetchData();
    }, []);

    const totalRecebidoMes = pagamentos
        .filter(p => new Date(p.data_pagamento).getMonth() === new Date().getMonth())
        .reduce((sum, p) => sum + p.valor_pago, 0);

    const totalAReceber = notas
        .map(n => n.valor_nota - getValorPagoPorNota(n.id, pagamentos))
        .reduce((sum, v) => sum + v, 0);
    
    const comissoesPendentes = comissoes
        .filter(c => c.valor_pago < c.valor_comissao)
        .reduce((sum, c) => sum + (c.valor_comissao - c.valor_pago), 0);

    const vendasPorCliente = clientes.map(cliente => {
        const pedidosCliente = pedidos.filter(p => p.cliente_id === cliente.id);
        const totalVendido = pedidosCliente.reduce((sum, p) => sum + getTotalPedido(p), 0);
        return { name: cliente.nome, 'Vendas (R$)': totalVendido };
    }).sort((a, b) => b['Vendas (R$)'] - a['Vendas (R$)']).slice(0, 5);

    if (loading) {
        return <div className="text-center p-8">Carregando dados...</div>;
    }

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>
            
            {/* KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <KpiCard icon={<DollarSign size={24}/>} title="Total Recebido (Mês)" value={formatCurrency(totalRecebidoMes)} />
                <KpiCard icon={<FileCheck2 size={24}/>} title="Total a Receber" value={formatCurrency(totalAReceber)} />
                <KpiCard icon={<AlertTriangle size={24}/>} title="Comissões Pendentes" value={formatCurrency(comissoesPendentes)} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Pagamentos Recentes */}
                <Card className="lg:col-span-1">
                    <h2 className="text-lg font-semibold text-gray-800 mb-4">Pagamentos Recentes</h2>
                    <div className="space-y-3">
                        {pagamentos.slice(0, 5).map(p => {
                            const nota = notas.find(n => n.id === p.nota_id);
                            const pedido = nota ? pedidos.find(pd => pd.id === nota.pedido_id) : undefined;
                            const cliente = pedido ? clientes.find(c => c.id === pedido.cliente_id) : undefined;
                            return (
                                <div key={p.id} className="text-sm p-2 rounded-md hover:bg-gray-50">
                                    <div className="flex justify-between font-semibold">
                                        <span>{cliente?.nome || 'N/A'}</span>
                                        <span>{formatCurrency(p.valor_pago)}</span>
                                    </div>
                                    <div className="text-xs text-gray-500">
                                        Nota {nota?.numero}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </Card>

                {/* Performance */}
                <Card className="lg:col-span-2">
                    <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                        <BarChart2 className="mr-2 text-agro-green" />
                        Performance de Vendas por Cliente
                    </h2>
                    <div style={{ width: '100%', height: 300 }}>
                        <ResponsiveContainer>
                            <BarChart data={vendasPorCliente} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                                <YAxis tickFormatter={(value) => `${formatCurrency(Number(value)/1000)}k`} />
                                <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                                <Legend />
                                <Bar dataKey="Vendas (R$)" fill="#1A472A" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default Dashboard;