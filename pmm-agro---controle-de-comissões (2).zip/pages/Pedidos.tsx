import React, { useEffect, useState } from 'react';
import { Cliente, Pedido, Nota, Pagamento } from '../types.ts';
import { apiService } from '../services/apiService.ts';
import { formatCurrency, formatDate, getTotalPedido, getValorRecebidoPorPedido, getPercentualPagoPedido, getStatusPedido } from '../utils/helpers.ts';
import Card from '../components/ui/Card.tsx';
import StatusBadge from '../components/ui/StatusBadge.tsx';

const Pedidos: React.FC = () => {
    const [clientes, setClientes] = useState<Cliente[]>([]);
    const [pedidos, setPedidos] = useState<Pedido[]>([]);
    const [notas, setNotas] = useState<Nota[]>([]);
    const [pagamentos, setPagamentos] = useState<Pagamento[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            const [cls, pds, nts, pgs] = await Promise.all([
                apiService.getClientes(),
                apiService.getPedidos(),
                apiService.getNotas(),
                apiService.getPagamentos(),
            ]);
            setClientes(cls);
            setPedidos(pds);
            setNotas(nts);
            setPagamentos(pgs);
            setLoading(false);
        };
        fetchData();
    }, []);

    if (loading) {
        return <div>Carregando pedidos...</div>;
    }

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-800">Pedidos</h1>
            <Card>
                 <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pedido</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Valor Total</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Valor Recebido</th>
                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">% Pago</th>
                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {pedidos.map((pedido) => {
                                const cliente = clientes.find(c => c.id === pedido.cliente_id);
                                const valorTotal = getTotalPedido(pedido);
                                const valorRecebido = getValorRecebidoPorPedido(pedido.id, notas, pagamentos);
                                const percentualPago = getPercentualPagoPedido(pedido, valorRecebido);
                                const status = getStatusPedido(percentualPago);

                                return (
                                    <tr key={pedido.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-agro-green">{pedido.numero}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">{cliente?.nome}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatDate(pedido.data_pedido)}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-800 font-medium">{formatCurrency(valorTotal)}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-green-600 font-medium">{formatCurrency(valorRecebido)}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-center">
                                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                                                <div className="bg-agro-green h-2.5 rounded-full" style={{ width: `${percentualPago.toFixed(2)}%` }}></div>
                                            </div>
                                            <span className="text-xs text-gray-500">{percentualPago.toFixed(2)}%</span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-center">
                                            <StatusBadge status={status} />
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default Pedidos;