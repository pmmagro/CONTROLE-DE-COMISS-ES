import React, { useEffect, useState } from 'react';
import { Cliente, Comissao, Nota } from '../types.ts';
import { apiService } from '../services/apiService.ts';
import { formatCurrency, formatDate, getStatusComissao } from '../utils/helpers.ts';
import Card from '../components/ui/Card.tsx';
import StatusBadge from '../components/ui/StatusBadge.tsx';

const Comissoes: React.FC = () => {
    const [clientes, setClientes] = useState<Cliente[]>([]);
    const [comissoes, setComissoes] = useState<Comissao[]>([]);
    const [notas, setNotas] = useState<Nota[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            const [cls, cms, nts] = await Promise.all([
                apiService.getClientes(),
                apiService.getComissoes(),
                apiService.getNotas(),
            ]);
            setClientes(cls);
            setComissoes(cms);
            setNotas(nts);
            setLoading(false);
        };
        fetchData();
    }, []);

    if (loading) {
        return <div>Carregando comissões...</div>;
    }

    return (
        <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-800">Comissões</h1>
            <Card>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nota</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
                                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Comissão Devida</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Comissão Paga</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Saldo</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {comissoes.map((comissao) => {
                                const cliente = clientes.find(c => c.id === comissao.cliente_id);
                                const nota = notas.find(n => n.id === comissao.nota_id);
                                const status = getStatusComissao(comissao);
                                const saldo = comissao.valor_comissao - comissao.valor_pago;

                                return (
                                    <tr key={comissao.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-agro-green">{nota?.numero}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">{cliente?.nome}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatDate(comissao.created_at)}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-center">
                                            <StatusBadge status={status} />
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-800 font-medium">{formatCurrency(comissao.valor_comissao)}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-green-600 font-medium">{formatCurrency(comissao.valor_pago)}</td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-bold">{formatCurrency(saldo)}</td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

export default Comissoes;