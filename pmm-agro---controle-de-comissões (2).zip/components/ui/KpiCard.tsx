import React from 'react';
import Card from './Card.tsx';

interface KpiCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  description?: string;
  className?: string;
}

const KpiCard: React.FC<KpiCardProps> = ({ icon, title, value, description, className }) => {
  return (
    <Card className={`flex items-start ${className}`}>
      <div className="flex-shrink-0 mr-4 text-agro-green bg-green-100 rounded-full p-3">
        {icon}
      </div>
      <div>
        <h3 className="text-sm font-medium text-agro-gray uppercase">{title}</h3>
        <p className="mt-1 text-2xl font-semibold text-gray-900">{value}</p>
        {description && <p className="text-sm text-gray-500 mt-1">{description}</p>}
      </div>
    </Card>
  );
};

export default KpiCard;