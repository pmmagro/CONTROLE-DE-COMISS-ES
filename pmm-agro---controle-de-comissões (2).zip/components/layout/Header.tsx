import React, { useContext } from 'react';
import { UserContext } from '../../App.tsx';
import { UserCircle, LogOut } from 'lucide-react';

const Header: React.FC = () => {
  const { user, logout } = useContext(UserContext);

  return (
    <header className="flex items-center justify-end h-16 bg-white border-b border-gray-200 px-4 sm:px-6">
      <div className="flex items-center">
        <div className="text-right mr-4">
          <p className="font-semibold text-gray-800">{user?.name}</p>
          <p className="text-xs text-agro-gray">{user?.role}</p>
        </div>
        <UserCircle className="h-8 w-8 text-agro-gray" />
        <button onClick={logout} className="ml-4 p-2 rounded-full hover:bg-gray-100 text-agro-gray hover:text-red-600 transition-colors">
            <LogOut className="h-5 w-5" />
        </button>
      </div>
    </header>
  );
};

export default Header;