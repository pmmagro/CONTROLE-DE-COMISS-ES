
import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, ShoppingCart, Percent, FileText, Wheat } from 'lucide-react';

const navLinks = [
  { to: '/dashboard', icon: LayoutDashboard, text: 'Dashboard' },
  { to: '/clientes', icon: Users, text: 'Clientes' },
  { to: '/pedidos', icon: ShoppingCart, text: 'Pedidos' },
  { to: '/comissoes', icon: Percent, text: 'Comissões' },
  { to: '/relatorios', icon: FileText, text: 'Relatórios' },
];

const Sidebar: React.FC = () => {
  const linkClasses = "flex items-center px-4 py-2.5 text-gray-200 hover:bg-agro-green/50 rounded-md transition-colors duration-200";
  const activeLinkClasses = "bg-agro-green/70 text-white font-semibold";

  return (
    <aside className="hidden md:flex w-64 flex-col bg-agro-green-darker text-white" style={{backgroundColor: '#11331F'}}>
      <div className="flex items-center justify-center h-20 border-b border-agro-green/30">
        <Wheat className="h-8 w-8 text-agro-gold" />
        <span className="ml-3 text-2xl font-bold text-white">PMM AGRO</span>
      </div>
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navLinks.map(({ to, icon: Icon, text }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) => `${linkClasses} ${isActive ? activeLinkClasses : ''}`}
          >
            <Icon className="h-5 w-5 mr-3" />
            {text}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
