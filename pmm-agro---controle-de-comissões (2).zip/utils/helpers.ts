import { Nota, Pagamento, Pedido, Comissao, StatusPagamento } from '../types.ts';

export const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

export const formatDate = (date: Date): string => {
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(date);
};

export const getValorPagoPorNota = (notaId: string, pagamentos: Pagamento[]): number => {
  return pagamentos
    .filter((p) => p.nota_id === notaId)
    .reduce((sum, p) => sum + p.valor_pago, 0);
};

export const getStatusNota = (nota: Nota, valorPago: number): StatusPagamento => {
  if (valorPago <= 0) return StatusPagamento.Aberta;
  if (valorPago < nota.valor_nota) return StatusPagamento.Parcial;
  return StatusPagamento.Paga;
};

export const getValorRecebidoPorPedido = (pedidoId: string, notas: Nota[], pagamentos: Pagamento[]): number => {
    const notasDoPedido = notas.filter(n => n.pedido_id === pedidoId);
    return notasDoPedido.reduce((total, nota) => total + getValorPagoPorNota(nota.id, pagamentos), 0);
}

export const getTotalPedido = (pedido: Pedido): number => {
    return pedido.tons * pedido.preco_ton;
}

export const getPercentualPagoPedido = (pedido: Pedido, valorRecebido: number): number => {
    const total = getTotalPedido(pedido);
    if (total === 0) return 0;
    return (valorRecebido / total) * 100;
}

export const getStatusPedido = (percentualPago: number): StatusPagamento => {
    if (percentualPago <= 0) return StatusPagamento.Aguardando;
    if (percentualPago < 100) return StatusPagamento.Parcial;
    return StatusPagamento.Totalmente;
}

export const getStatusComissao = (comissao: Comissao): StatusPagamento => {
    if (comissao.valor_pago <= 0) return StatusPagamento.Pendente;
    if (comissao.valor_pago < comissao.valor_comissao) return StatusPagamento.Parcial;
    return StatusPagamento.Paga;
}

export const getDiasAtraso = (pagamento: Pagamento): number | null => {
    if (!pagamento.vencimento_original) return null;
    const diffTime = pagamento.data_pagamento.getTime() - pagamento.vencimento_original.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
}